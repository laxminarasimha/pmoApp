var appConstants = angular.module('appConstants', []);

appConstants
		.constant(
				"appConstants",
				{
					"right_reserve" : "@All Copyright to Capgemini 2017",
          "UserName" : "username",  					
					"DB_ERROR" : "4"

				});
